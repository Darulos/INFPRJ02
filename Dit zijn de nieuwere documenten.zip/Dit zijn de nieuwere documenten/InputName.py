import sys, os

import Variables
import pygame
import Score

from INFPRJ02 import InputPosition


def InputName():
    loop = True
    PlayerName = ""
    # alvast font vaststellen
    font = pygame.font.Font(None, 30)
    # loop om het programma lopend te houden
    while loop:
        # loopt alle events door op zoek naar een van de if's
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                # zet de aangetikte letter/hoofdletter in antwoord
                if event.unicode.isalpha():
                    PlayerName += event.unicode

                # zet de aangetikte cijfer in antwoord
                elif event.unicode.isdigit():
                    PlayerName += event.unicode

                # zet de aangetikte spatie in antwoord
                elif event.key == pygame.K_SPACE:
                    PlayerName += " "

                # zet de aangetikte punt in antwoord
                elif event.key == pygame.K_PERIOD:
                    PlayerName += "."

                # maakt antwoord 1 lengte korter wanneer backspace wordt aangetikt
                elif event.key == pygame.K_BACKSPACE:
                    PlayerName = PlayerName[:-1]

                # checkt gegeven antwoord met het answer in de database en haalt antwoord leeg
                elif event.key == pygame.K_RETURN:
                    if not Score.interact_database("select name from score where name = %s", False, (Variables.Player_Name,)):
                        Score.interact_database("INSERT INTO Score VALUES(%s, %s)", True, (Variables.Player_Name, 0))
                    InputPosition.InputPosition()
            elif event.type is pygame.QUIT:
                pygame.quit()
                sys.exit()
        background = pygame.image.load(os.path.join("Images", "Play_Background.png"))
        background2 = pygame.transform.scale(background, (1920, 1080))
        Variables.game.screen.blit(background2, (0, 0))

        name_display = "Wat is uw naam?"
        name_block = font.render(name_display, 1, (255, 255, 255))
        name_rect = name_block.get_rect(center=(640, 250))
        Variables.game.screen.blit(name_block, name_rect)

        block = font.render(PlayerName, 1, (255, 255, 255))
        rect = block.get_rect(center=(640, 400))
        Variables.game.screen.blit(block, rect)

        pygame.display.flip()

    Variables.function = "Menu_return"
    Variables.game.update()
