import random
import sys

import Score
import Variables
import gameboard
import psycopg2
import pygame
import Draw


def interact_database(command, params=None):
    connection = psycopg2.connect("dbname=INF1H_Project_2_Group_4 user=postgres password=INF1HGroup4")
    cursor = connection.cursor()
    cursor.execute(command, params)
    connection.commit()

    results = None
    try:
        results = cursor.fetchall()
    except psycopg2.ProgrammingError:
        print("Connection failure.")
        pass

    cursor.close()
    connection.close()

    return results


def pick_number(type):
    if type == 'g':
        QuestionID = random.randint(1, 38)
    elif type == 'gr':
        QuestionID = random.randint(39, 60)
    elif type == 'r':
        QuestionID = random.randint(61, 89)
    elif type == 'b':
        QuestionID = random.randint(90, 119)
    else:
        QuestionID = random.randint(1, 119)
    return QuestionID


def question(number):
    return interact_database("SELECT Question FROM Questions WHERE Question_ID = %s", (number,))[0][0]


def possibilities(number):
    return interact_database("SELECT Possibilities FROM Questions WHERE Question_ID = %s", (number,))[0][0]


def answers(number):
    return interact_database("SELECT Answers FROM Questions WHERE Question_ID = %s", (number,))[0][0]


def begin():
    num = pick_number(Variables.questionType)
    Variables.questionint = num

'''
def GameTimer():
    clock = pygame.time.Clock()
    clock.tick(1)
    clock_variable = 5
    if int(clock.get_fps() * 5) % 60 == 0:
        Variables.QuestionTimer -= 1
        if Variables.QuestionTimer == 0:
            Variables.Correct = False
            Variables.QuestionTimer = 10
'''


def typen():
    Variables.Playerscore = 0
    highscore = str(interact_database("SELECT MAX(Score) FROM score;",)[0][0])
    # variable om het getypte antwoord op te slaan
    boardloop = True
    loop = True
    antwoord = ""
    # loop om het programma lopend te houden
    while loop:
        Draw.draw()
        # loopt alle events door op zoek naar een van de if's
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                # zet de aangetikte letter/hoofdletter in antwoord
                if event.unicode.isalpha():
                    antwoord += event.unicode
                    Draw.draw()

                # zet de aangetikte cijfer in antwoord
                elif event.unicode.isdigit():
                    antwoord += event.unicode
                    Draw.draw()

                # zet de aangetikte spatie in antwoord
                elif event.key == pygame.K_SPACE:
                    antwoord += " "
                    Draw.draw()

                # zet de aangetikte punt in antwoord
                elif event.key == pygame.K_PERIOD:
                    antwoord += "."
                    Draw.draw()

                # maakt antwoord 1 lengte korter wanneer backspace wordt aangetikt
                elif event.key == pygame.K_BACKSPACE:
                    antwoord = antwoord[:-1]
                    Draw.draw()

                # checkt gegeven antwoord met het answer in de database en haalt antwoord leeg
                elif event.key == pygame.K_RETURN:
                    Draw.draw()
                    # if antwoord in answer, display correct, score +=
                    # haalt antwoord op uit database
                    tempantwoord = antwoord.upper()
                    Variables.antwoord = antwoord
                    if tempantwoord.upper() in answers(Variables.questionint).upper():# and antwoord is not "":
                        Variables.Correct = True
                    else:
                        Variables.Correct = False
                    if Variables.Correct is True:
                        # antwoord is leeg zodat deze voor de volgende vraag hergebruikt kan worden
                        antwoord = ""
                        print("Goed zo jongen")
                        # update de huidige score
                        Variables.PlayerScore += 10
                        # als je huidige score hoger is dan die in de database onder de ingevoerde naam wordt het geupdate
                        BlijkbaarIsDitNodig = interact_database("SELECT Score, Name FROM score WHERE Name = %s", (Variables.Player_Name,))[0][0]
                        if Variables.PlayerScore > BlijkbaarIsDitNodig:
                            Score.upload_score(Variables.PlayerScore, Variables.Player_Name)
                        Variables.QuestionTimer = 50
                        Variables.questionType = ''
                        loop = False
                        while boardloop:
                            gameboard.board.draw(Variables.game.screen)
                            Variables.player1.update()
                            Variables.player1.draw(Variables.game.screen)
                            pygame.display.flip()
                            boardloop = False

                    elif Variables.Correct is False:
                        antwoord = ""
                        print("Goed antwoord: ")
                        # print het goede antwoord op de vraag
                        # print(answers(Variables.questionint))
                        # print("Hoogste score:")
                        # geeft alleen de hoogste score weer
                        # print(interact_database("SELECT MAX(Score) FROM score;")[0][0])
                        # geeft de speler de kans om nog even te kijken als dit in de pygame screen wordt weergegeven
                        # game gaat verder maar de speler mag niet bewegen
                        Variables.QuestionTimer = 50
                        Variables.questionType = ''
                        loop = False
                        while boardloop:
                            gameboard.board.draw(Variables.game.screen)
                            Variables.player1.draw(Variables.game.screen)
                            boardloop = False
            elif event.type is pygame.QUIT:
                pygame.quit()
                sys.exit()

    Variables.function = "Menu_return"
    Variables.game.update()
