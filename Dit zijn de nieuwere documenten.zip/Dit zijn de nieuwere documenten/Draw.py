import pygame, os
import typen
import Variables


def draw():
    Dice1 = pygame.image.load(os.path.join('Images', 'Dice1.png'))
    Dice2 = pygame.image.load(os.path.join('Images', 'Dice2.png'))
    Dice3 = pygame.image.load(os.path.join('Images', 'Dice3.png'))
    Dice4 = pygame.image.load(os.path.join('Images', 'Dice4.png'))
    Dice5 = pygame.image.load(os.path.join('Images', 'Dice5.png'))
    Dice6 = pygame.image.load(os.path.join('Images', 'Dice6.png'))
    font = pygame.font.Font(None, 30)
    background = pygame.image.load(os.path.join("Images", "Play_Background.png"))
    background2 = pygame.transform.scale(background, (1920, 1080))
    Variables.game.screen.blit(background2, (0, 0))
    if Variables.color == "Rood":
        kaart = pygame.image.load(os.path.join("Images", "Card_Red.png"))
        kaart2 = pygame.transform.scale(kaart, (480, 560))
        Variables.game.screen.blit(kaart2, (10, 160))
    elif Variables.color == "Groen":
        kaart = pygame.image.load(os.path.join("Images", "Card_Green.png"))
        kaart2 = pygame.transform.scale(kaart, (480, 560))
        Variables.game.screen.blit(kaart2, (10, 160))
    elif Variables.color == "Geel":
        kaart = pygame.image.load(os.path.join("Images", "Card_Yellow.png"))
        kaart2 = pygame.transform.scale(kaart, (480, 560))
        Variables.game.screen.blit(kaart2, (10, 160))
    elif Variables.color == "Blauw":
        kaart = pygame.image.load(os.path.join("Images", "Card_Blue.png"))
        kaart2 = pygame.transform.scale(kaart, (480, 560))
        Variables.game.screen.blit(kaart2, (10, 160))
    if not Variables.win_game:
        # setting the standard width of a square
        w = 48
        # setting values for the x,y axis
        x, y = 608, 90
        # loop for the y axis of the grid
        for i in range(15):
            # loop for the x axis of the grid
            for j in range(8):
                # the board is 15 high but is 8 wide until it gets to the top 5 and since its drawn from top to bottom
                # the first 5 rows are only 4 wide and need a special if
                if i > 4:
                    # draws a black square behind every coloured square to give it better contrast
                    pygame.draw.rect(Variables.game.screen, (0, 0, 0), (x, y, w, w))
                    # for loop that draws 42 lines in slightly darker colour to create a gradient square
                    for k in range(42):
                        if j == 0 or j == 1:
                            color = (255 - k, 0, 0)
                            pygame.draw.line(Variables.game.screen, color, (x + k + 3, y + 3), (x + k + 3, y + 45))
                        elif j == 2 or j == 3:
                            color = (0, 255 - k, 0)
                            pygame.draw.line(Variables.game.screen, color, (x + k + 3, y + 3), (x + k + 3, y + 45))
                        elif j == 4 or j == 5:
                            color = (255 - k, 255 - k, 0)
                            pygame.draw.line(Variables.game.screen, color, (x + k + 3, y + 3), (x + k + 3, y + 45))
                        elif j == 6 or j == 7:
                            color = (0, 0, 255 - k)
                            pygame.draw.line(Variables.game.screen, color, (x + k + 3, y + 3), (x + k + 3, y + 45))
                else:
                    # draws a black square behind every coloured square to give it better contrast but because these rows
                    # are only 4 wide they need half the black squares
                    if j % 2 == 0:
                        pygame.draw.rect(Variables.game.screen, (0, 0, 0), (x + 24, y, w, w))
                    # for loop that draws 42 lines in slighty darker colour to create a gradient square but because these
                    # rows are only 4 wide they need half the coloured squares therefore they only draw when j is even
                    for k in range(42):
                        if j == 0:
                            color = (0, 0, 255 - k)
                            pygame.draw.line(Variables.game.screen, color, (x + k + 27, y + 3), (x + k + 27, y + 45))
                        elif j == 2:
                            color = (255 - k, 255 - k, 0)
                            pygame.draw.line(Variables.game.screen, color, (x + k + 27, y + 3), (x + k + 27, y + 45))
                        elif j == 4:
                            color = (0, 255 - k, 0)
                            pygame.draw.line(Variables.game.screen, color, (x + k + 27, y + 3), (x + k + 27, y + 45))
                        elif j == 6:
                            color = (255 - k, 0, 0)
                            pygame.draw.line(Variables.game.screen, color, (x + k + 27, y + 3), (x + k + 27, y + 45))
                # increase the value of the x axis by w so that the next square thats created is to the right of the
                # previous one and not on top
                x += w
            # increase the value of the y axis by w so that the next square thats created is below the previous and not
            # on top
            y += w
            # reset the value of the x axis so that the next row starts at same spot as the previous row
            x = 608
        Variables.player1.draw(Variables.game.screen)

        score_display = Variables.PlayerScore
        score_block = font.render("score: {}".format(score_display), 1, (255, 255, 255))
        Variables.game.screen.blit(score_block, (1400, 16))
        if Variables.dobbelsteen_draw is True:
            if Variables.number == 1:
                Variables.game.screen.blit(Dice1, (1450, 450))
            if Variables.number == 2:
                Variables.game.screen.blit(Dice2, (1450, 450))
            if Variables.number == 3:
                Variables.game.screen.blit(Dice3, (1450, 450))
            if Variables.number == 4:
                Variables.game.screen.blit(Dice4, (1450, 450))
            if Variables.number == 5:
                Variables.game.screen.blit(Dice5, (1450, 450))
            if Variables.number == 6:
                Variables.game.screen.blit(Dice6, (1450, 450))
        # vult het scherm zwart
        # zorgt ervoor dat Number.PlayerScore wordt weergegeven. KNK
        # zegt wat question is
        converter = typen.question(Variables.questionint)[0:30]
        question_block1 = font.render(converter, 1, (255, 255, 255))
        question_rect1 = question_block1.get_rect(center=(300, 200))

        converter = typen.question(Variables.questionint)[30:60]
        question_block2 = font.render(converter, 1, (255, 255, 255))
        question_rect2 = question_block2.get_rect(center=(300, 250))

        converter = typen.question(Variables.questionint)[60:90]
        question_block3 = font.render(converter, 1, (255, 255, 255))
        question_rect3 = question_block3.get_rect(center=(300, 300))

        converter = typen.question(Variables.questionint)[90:120]
        question_block4 = font.render(converter, 1, (255, 255, 255))
        question_rect4 = question_block4.get_rect(center=(300, 350))

        converter = typen.question(Variables.questionint)[120:150]
        question_block5 = font.render(converter, 1, (255, 255, 255))
        question_rect5 = question_block5.get_rect(center=(300, 400))

        converter = typen.possibilities(Variables.questionint)
        if converter != "":
            poss_index1 = converter.index('B ')
            poss_index2 = converter.index('C ')
            converter = typen.possibilities(Variables.questionint)[0:poss_index1]
            poss_blockA = font.render(converter, 1, (255, 255, 255))
            poss_rectA = poss_blockA.get_rect(center=(300, 450))
            Variables.game.screen.blit(poss_blockA, poss_rectA)

            converter = typen.possibilities(Variables.questionint)[poss_index1: poss_index2]
            poss_blockB = font.render(converter, 1, (255, 255, 255))
            poss_rectB = poss_blockB.get_rect(center=(300, 500))
            Variables.game.screen.blit(poss_blockB, poss_rectB)

            converter = typen.possibilities(Variables.questionint)[poss_index2:]
            poss_blockC = font.render(converter, 1, (255, 255, 255))
            poss_rectC = poss_blockC.get_rect(center=(300, 550))
            Variables.game.screen.blit(poss_blockC, poss_rectC)
        else:
            poss_block = font.render(converter, 1, (255, 255, 255))
            poss_rect = poss_block.get_rect(center=(300, 450))
            Variables.game.screen.blit(poss_block, poss_rect)

        '''
        hi_display = highscore
        hi_block = font.render(hi_display, 1, (255, 255, 255))
        hi_rect = hi_block.get_rect(center=(640, 250))
        Variables.game.screen.blit(hi_block, hi_rect)
        '''
        '''
        GameTimer()
        timer_display = "Tijd over: {}".format(Variables.QuestionTimer)
        timer_block = score_font.render(timer_display, 1, (255, 255, 255))
        timer_rect = timer_block.get_rect(center=(1400, 884))
        Variables.game.screen.blit(timer_block, timer_rect)
        '''

        # geeft het antwoord weer
        block = font.render(Variables.antwoord, 1, (255, 255, 255))
        # positie antwoord
        rect = block.get_rect(center=(300, 600))
        # geeft antwoord weer
        # geeft de hoogste score weer
        # geeft answer weer

        # geeft question weer
        Variables.game.screen.blit(question_block1, question_rect1)
        Variables.game.screen.blit(question_block2, question_rect2)
        Variables.game.screen.blit(question_block3, question_rect3)
        Variables.game.screen.blit(question_block4, question_rect4)
        Variables.game.screen.blit(question_block5, question_rect5)
        Variables.game.screen.blit(block, rect)

        if not Variables.Correct:
            answer_display = typen.answers(Variables.questionint)
            answer_block = font.render(answer_display, 1, (255, 255, 255))
            answer_rect = answer_block.get_rect(center=(300, 650))
            Variables.game.screen.blit(answer_block, answer_rect)

    elif Variables.win_game is True:
        Variables.game.screen.fill((0, 0, 0))
        win_block = font.render("JE HEBT GEWONNEN JIJ BENT ECHT WEL DE COOLSTE", 1, (255, 255, 255))
        win_rect = win_block.get_rect(center=(800, 450))
        Variables.game.screen.blit(win_block, win_rect)

        # flipt de screens zodat deze info zichtbaar wordt
    pygame.display.flip()
