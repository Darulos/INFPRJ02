import pygame, random
import Variables
import typen
import Draw


def questionType():
    if Variables.player1x < 704:
        Variables.questionType = 'r'
        Variables.color = "Rood"
    elif Variables.player1x < 800:
        Variables.questionType = 'gr'
        Variables.color = "Groen"
    elif Variables.player1x < 896:
        Variables.questionType = 'g'
        Variables.color = "Geel"
    elif Variables.player1x < 992:
        Variables.questionType = 'b'
        Variables.color = "Blauw"
    else:
        Variables.questionType = 'xd'


class board:
    def draw(screen):
        Draw.draw()


# class to keep track of the different avatars and their positions
# id dfferentiates between the different avatars and x,y are the coordinates
class avatars:
    def __init__(self, id, x, y):
        self.id = id
        self.x = x
        self.y = y

    def movement(self, number):
        if number == 1 or number == 2:
            return 1
        elif number == 3 or number == 4:
            return 2
        elif number == 5 or number == 6:
            return 3

    # function to update the the position of a a player
    def update(self):
        # loops through the button presses to check what direction the player wants to go to
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                # checks if the left arrow key has been pressed and changes the x value to move the avatar
                if event.key == pygame.K_LEFT:
                    questionType()
                    typen.begin()
                    typen.typen()
                    Variables.number = random.randint(1, 6)
                    Variables.dobbelsteen_draw = True
                    if Variables.Correct is True:
                        # stel vraag if antwoord is goed beweeg
                        if Variables.player1y < 308:
                            Variables.player1x -= 96 * self.movement(Variables.number) #* random.randint(1,3)
                            # if the avatar is moved outside the bord it gets placed on the right of the board because its
                            # supposed to be circular
                            if Variables.player1x < 632:
                                Variables.player1x += 384
                        else:
                            Variables.player1x -= 48 * self.movement(Variables.number)#* random.randint(1,3)#* dice throw
                            # if the avatar is moved outside the bord it gets placed on the right of the board because its
                            # supposed to be circular
                            if Variables.player1x < 608:
                                Variables.player1x += 384
                # checks if the right arrow key has been pressed and changes the x value to move the avatar
                elif event.key == pygame.K_RIGHT:
                    questionType()
                    typen.begin()
                    typen.typen()
                    Variables.number = random.randint(1, 6)
                    Variables.dobbelsteen_draw = True
                    # throw dice
                    if Variables.Correct is True:
                        if Variables.player1y < 308:
                            Variables.player1x += 96 * self.movement(Variables.number)#* random.randint(1,3)
                            # if the avatar is moved outside the bord it gets placed on the left of the board because its
                            # supposed to be circular
                            if Variables.player1x > 968:
                                Variables.player1x -= 384
                        else:
                            Variables.player1x += 48 # * random.randint(1,3)#* dice throw
                            # if the avatar is moved outside the bord it gets placed on the left of the board because its
                            # supposed to be circular
                            if Variables.player1x > 992:
                                Variables.player1x -= 384
                # checks if the up arrow key has been pressed and changes the y value to move the avatar
                elif event.key == pygame.K_UP:
                    tempy = Variables.player1y
                    questionType()
                    typen.begin()
                    typen.typen()
                    Variables.number = random.randint(1, 6)
                    Variables.dobbelsteen_draw = True
                    if Variables.Correct is True:
                        Variables.player1y -= 48 * self.movement(Variables.number)  # * random.randint(1,3)#* dice throw
                        if tempy > 308 and Variables.player1y <= 308:
                            if Variables.player1x == 632:
                                Variables.player1x += 24
                            elif Variables.player1x == 680:
                                Variables.player1x -= 24
                            elif Variables.player1x == 728:
                                Variables.player1x += 24
                            elif Variables.player1x == 776:
                                Variables.player1x -= 24
                            elif Variables.player1x == 824:
                                Variables.player1x += 24
                            elif Variables.player1x == 872:
                                Variables.player1x -= 24
                            elif Variables.player1x == 920:
                                Variables.player1x += 24
                            elif Variables.player1x == 968:
                                Variables.player1x -= 24
                            # if the avatar is moved above the board it gets placed on top of the board and the player wins
                        if Variables.player1y <= 138:
                            Variables.player1y = 138
                            Variables.win_game = True
                            # winnaar!!!!!!!
                # checks if the down arrow key has been pressed and changes the y value to move the avatar
                elif event.key == pygame.K_DOWN:
                    tempy = Variables.player1y
                    questionType()
                    typen.begin()
                    typen.typen()
                    Variables.number = random.randint(1, 6)
                    Variables.dobbelsteen_draw = True
                    if Variables.Correct is True:
                        Variables.player1y += 48 * self.movement(Variables.number)#* random.randint(1,3)#* dice throw
                        if tempy <= 308:
                            Variables.player1x += 24
                        # if the avatar is moved underneath the board it gets placed on at the bottom of the board
                        if Variables.player1y > 786:
                            Variables.player1y = 786

    def draw(self, screen):
        # load and draw the avatars(right now only 1 is drawn)
        img = pygame.image.load("Images/P1.png")
        rect = img.get_rect(center=(Variables.player1x, Variables.player1y))
        screen.blit(img, rect)
