import pygame
import sys, os
import Variables
import typen
import gameboard


def InputPosition():
    loop = True
    typecheck = True
    # alvast font vaststellen
    font = pygame.font.Font(None, 30)
    # loop om het programma lopend te houden
    while loop:
        # loopt alle events door op zoek naar een van de if's
        for event in pygame.event.get():
            startgame = True
            if event.type == pygame.KEYDOWN:
                # zet de aangetikte letter/hoofdletter in antwoord
                if event.unicode.isalpha():
                    Variables.startingplace += event.unicode
                # maakt antwoord 1 lengte korter wanneer backspace wordt aangetikt
                elif event.key == pygame.K_BACKSPACE:
                    Variables.startingplace = Variables.startingplace[:-1]
                # checkt gegeven antwoord met het answer in de database en haalt antwoord leeg
                elif event.key == pygame.K_RETURN:
                    if Variables.startingplace.lower() == "rood":
                        Variables.player1x = 632
                        Variables.player1y = 786
                    elif Variables.startingplace.lower() == "groen":
                        Variables.player1x = 728
                        Variables.player1y = 786
                    elif Variables.startingplace.lower() == "geel":
                        Variables.player1x = 824
                        Variables.player1y = 786
                    elif Variables.startingplace.lower() == "blauw":
                        Variables.player1x = 920
                        Variables.player1y = 786
                    else:
                        startgame = False
                    if typecheck is True:
                            typen.begin()
                            typecheck = False
                    while startgame is True:
                        Variables.player1 = gameboard.avatars(1, 48, 24)
                        gameboard.board.draw(Variables.game.screen)
                        Variables.player1.update()
                        Variables.player1.draw(Variables.game.screen)
                        pygame.display.flip()

            elif event.type is pygame.QUIT:
                pygame.quit()
                sys.exit()
        background = pygame.image.load(os.path.join("Images", "Play_Background.png"))
        background2 = pygame.transform.scale(background, (1920, 1080))
        Variables.game.screen.blit(background2, (0, 0))

        place_display = "Wilt u beginnen op rood, groen, geel of blauw?"
        place_block = font.render(place_display, 1, (255, 255, 255))
        place_rect = place_block.get_rect(center=(640, 250))
        Variables.game.screen.blit(place_block, place_rect)

        block = font.render(Variables.startingplace, 1, (255, 255, 255))
        rect = block.get_rect(center=(640, 400))
        Variables.game.screen.blit(block, rect)

        pygame.display.flip()

    Variables.function = "Menu_return"
    Variables.game.update()
